package com.example.project_leap_25cc057_sudharsan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLeap25cc057SudharsanApplicationTests {

	@Test
	void contextLoads() {
	}

}
