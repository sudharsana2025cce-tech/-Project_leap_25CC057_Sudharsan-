package com.example.project_leap_25cc057_sudharsan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLeap25cc057SudharsanApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLeap25cc057SudharsanApplication.class, args);
	}

}
